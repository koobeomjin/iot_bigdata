#include <stdio.h>
#pragma warning (disable:4996)

void main(){
	int arr1[2][4] = {
		{1,2,3,4},
		{5,6,7,8}
	};
	int arr2[4][2];



}

