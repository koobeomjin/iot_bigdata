#include <stdio.h>
#pragma warning (disable:4996)

void main() {

}