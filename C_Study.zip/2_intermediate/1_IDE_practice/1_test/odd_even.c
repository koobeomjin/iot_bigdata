#include <stdio.h>
#pragma warning (disable:4996)
int odd(int number1, int number2, int number3, int number4, int number5) {
	if

}






void main() {
	int input_number1;
	int input_number2;
	int input_number3;
	int input_number4;
	int input_number5;

	printf("�ټ����� ������ �Է��Ͻÿ�: ");
	scanf("%d %d %d %d %d", &input_number1, &input_number2, &input_number3, &input_number4, &input_number5);
	odd(input_number1, input_number2, input_number3, input_number4, input_number5);

}