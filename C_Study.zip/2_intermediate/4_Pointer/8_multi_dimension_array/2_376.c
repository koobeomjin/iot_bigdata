#include <stdio.h>
#pragma warning (disable:4996)

void main() {
	int arr1[3][2];
	int arr2[2][3];

}
