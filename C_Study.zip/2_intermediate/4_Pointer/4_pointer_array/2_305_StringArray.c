#include <stdio.h>
#pragma warning (disable:4996)

void main() {
	char *strArr[3]={"Simple", "String", "Array"};

	printf("%s \n", strArr[0]);
	printf("%s \n", strArr[1]);
	printf("%s \n", strArr[2]);
}
