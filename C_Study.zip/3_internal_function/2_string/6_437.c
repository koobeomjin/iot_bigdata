#include <stdio.h>
#pragma warning (disable:4996)

void main() {
	char str1[20] = "1234567890";
	char str2[20];
	char str3[5];

	strcpy(str2, str1);
	put(str2);

	strcpy(str2, str1, sizeof)

	str3[7] = 's';
	printf("str1: %s\n", str1);
	printf("str3: %s\n\n", str3);
}
