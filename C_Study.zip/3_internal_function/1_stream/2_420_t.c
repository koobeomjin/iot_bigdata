#include <stdio.h>
#pragma warning (disable:4996)

void main() {
	int ch1, ch2, ch3, ch4, ch5, ch6;
	
	
	ch1 = getchar();
/*	ch2 = getchar();
	ch3 = getchar();
	ch4 = getchar();
	ch5 = getchar();
	ch6 = getchar();
	*/

	putchar(ch1);
	/*putchar(ch2);
	putchar(ch3);
	putchar(ch4);
	putchar(ch5);
	putchar(ch6);*/
}